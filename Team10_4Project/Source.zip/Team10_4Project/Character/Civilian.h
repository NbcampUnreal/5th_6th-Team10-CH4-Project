// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "AbilitySystemInterface.h"
// #include "GameplayTagContainer.h"
#include "GameplayEffectTypes.h"
#include "InputActionValue.h" // UE 5.6 Enhanced Input
#include "Civilian.generated.h"

class UAbilitySystemComponent;
class UCivilianAttributeSet;
class UCameraComponent;
class USpringArmComponent;
class UInputMappingContext;
class UInputAction;
class UAnimMontage;

UCLASS()
class TEAM10_4PROJECT_API ACivilian : public ACharacter, public IAbilitySystemInterface
{
	GENERATED_BODY()

#pragma region Civilian Override

public:
	ACivilian();
    
	// IAbilitySystemInterface ����
	virtual UAbilitySystemComponent* GetAbilitySystemComponent() const override;
	
	// �ʱ�ȭ
	virtual void BeginPlay() override;
	virtual void PossessedBy(AController* NewController) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	virtual void OnRep_PlayerState() override;
	
#pragma endregion
	
#pragma region Civilian Components
public:
	FORCEINLINE USpringArmComponent* GetSpringArm() const { return SpringArm; }

	FORCEINLINE UCameraComponent* GetCamera() const { return Camera; }

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayerCharacter|Components")
	TObjectPtr<USpringArmComponent> SpringArm;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayerCharacter|Components")
	TObjectPtr<UCameraComponent> Camera;

#pragma endregion
	
#pragma region Civilian GAS
	
public:
	// GAS ������Ʈ
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "GAS")
	TObjectPtr<UAbilitySystemComponent> AbilitySystemComponent;

	// Attribute Set
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "GAS")
	TObjectPtr<UCivilianAttributeSet> AttributeSet;

	// �⺻ �����Ƽ ���
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "GAS|Abilities")
	TArray<TSubclassOf<class UGameplayAbility>> DefaultAbilities;

	// �⺻ ȿ�� ���
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "GAS|Effects")
	TArray<TSubclassOf<class UGameplayEffect>> DefaultEffects;

protected:
	// GAS �ʱ�ȭ - ASC �ʱ�ȭ ���� �и�
	void InitializeAbilitySystem();

#pragma endregion
	
#pragma region Civilian Input
	
public:
	// Enhanced Input �ݹ� �Լ���
	void Move(const FInputActionValue& Value);
	void Look(const FInputActionValue& Value);
	void StartJump();
	void StopJump();
	
protected:
	// Enhanced Input (UE 5.6)
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Input")
	class UInputMappingContext* DefaultMappingContext;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Input")
	class UInputAction* MoveAction;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Input")
	class UInputAction* LookAction;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Input")
	class UInputAction* JumpAction;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Input")
	class UInputAction* InteractAction;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Input")
	class UInputAction* AttackAction;
	
#pragma endregion
	
	// Attribute ���� �ݹ�
	virtual void OnHealthChanged(const FOnAttributeChangeData& Data);
	
	// ����
	UFUNCTION(BlueprintCallable, Category = "Combat")
	void TryAttack();
	
	// ��� ó��
	UFUNCTION(BlueprintImplementableEvent, Category = "Character")
	void OnDeath();

	UFUNCTION(NetMulticast, Reliable)
	void MulticastHandleDeath();
	
		/*
    // ��ȣ�ۿ�
    UFUNCTION(BlueprintCallable, Category = "Interaction")
    void TryInteract();

    // ������ ���
    UFUNCTION(BlueprintCallable, Category = "Item")
    void TryUseItem(int32 ItemSlot)
    */
};
