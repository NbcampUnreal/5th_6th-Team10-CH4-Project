// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "CivilianPlayerController.generated.h"

/**
 * 
 */
UCLASS()
class TEAM10_4PROJECT_API ACivilianPlayerController : public APlayerController
{
	GENERATED_BODY()
	
};
