// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "AbilitySystemComponent.h" // FOnAttributeChangeData, FDelegateHandle ����� ���� �ʿ�
#include "Abilities/GameplayAbilityTypes.h"
#include "GameplayTagContainer.h"
#include "GameplayEffectTypes.h"
#include "GameAttributeTypes.h"
#include "StaminaBarWidget.generated.h"

class UProgressBar;
class UAbilitySystemComponent;
/**
 * 
 */
UCLASS()
class TEAM10_4PROJECT_API UStaminaBarWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
    virtual void NativeConstruct() override;
    virtual void NativeDestruct() override;

    // HUD���� ASC�� �����Ͽ� �ʱ�ȭ
    void InitWithASC(UAbilitySystemComponent* ASC);

protected:
    // UMG ProgressBar
    UPROPERTY(meta = (BindWidget))
    TObjectPtr<UProgressBar> StaminaBar;

private:
    // Ability System Component (UI�� ���� ã�� ����, �ܺο��� ���Ե�)
    UPROPERTY()
    TObjectPtr<UAbilitySystemComponent> AbilitySystemComponent;

    // Delegate Handles (unbind �ʿ�)
    FDelegateHandle StaminaChangedHandle;
    FDelegateHandle MaxStaminaChangedHandle;

    void BindGASDelegates(UAbilitySystemComponent* ASC);

    void OnStaminaAttributeChanged(const FOnAttributeChangeData& Data);
    void OnMaxStaminaAttributeChanged(const FOnAttributeChangeData& Data);
    void UpdateStaminaBar(float CurrentStamina, float MaxStamina);

};
