#include "MenuPlayerController.h"

#include "Blueprint/UserWidget.h"
#include "OutGameUI/UI/MainMenuWidget.h"
#include "OutGameUI/UI/ServerBrowserWidget.h"
void AMenuPlayerController::BeginPlay()
{
    Super::BeginPlay();

    if (MainMenuWidgetClass)
    {
        UUserWidget* Widget =
            CreateWidget(this, MainMenuWidgetClass);

        if (Widget)
        {
            Widget->AddToViewport();
            SetInputMode(FInputModeUIOnly());
            bShowMouseCursor = true;
        }
    }
}


void AMenuPlayerController::ShowMainMenu()
{
    if (CurrentWidget)
    {
        CurrentWidget->RemoveFromParent();
        CurrentWidget = nullptr;
    }

    if (MainMenuWidgetClass)
    {
        CurrentWidget = CreateWidget(this, MainMenuWidgetClass);
        if (CurrentWidget)
        {
            CurrentWidget->AddToViewport();
        }
    }
}

void AMenuPlayerController::ShowServerBrowser()
{
    if (CurrentWidget)
    {
        CurrentWidget->RemoveFromParent();
        CurrentWidget = nullptr;
    }

    if (ServerBrowserWidgetClass)
    {
        CurrentWidget = CreateWidget(this, ServerBrowserWidgetClass);
        if (CurrentWidget)
        {
            CurrentWidget->AddToViewport();
        }
    }
}
