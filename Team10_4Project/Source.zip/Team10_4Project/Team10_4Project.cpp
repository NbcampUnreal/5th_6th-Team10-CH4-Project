// Copyright Epic Games, Inc. All Rights Reserved.

#include "Team10_4Project.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Team10_4Project, "Team10_4Project" );

DEFINE_LOG_CATEGORY(LogTeam10_4Project)