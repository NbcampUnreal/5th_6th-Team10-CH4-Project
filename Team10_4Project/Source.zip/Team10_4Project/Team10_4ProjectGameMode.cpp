// Copyright Epic Games, Inc. All Rights Reserved.

#include "Team10_4ProjectGameMode.h"

ATeam10_4ProjectGameMode::ATeam10_4ProjectGameMode()
{
	// stub
}
