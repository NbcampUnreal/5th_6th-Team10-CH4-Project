// Copyright Epic Games, Inc. All Rights Reserved.


#include "Variant_Combat/CombatGameMode.h"

ACombatGameMode::ACombatGameMode()
{

}