// Copyright Epic Games, Inc. All Rights Reserved.


#include "CombatDamageable.h"

// Add default functionality here for any ICombatDamageable functions that are not pure virtual.
