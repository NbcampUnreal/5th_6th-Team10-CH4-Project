// Copyright Epic Games, Inc. All Rights Reserved.


#include "Variant_Platforming/PlatformingGameMode.h"

APlatformingGameMode::APlatformingGameMode()
{
	// stub
}