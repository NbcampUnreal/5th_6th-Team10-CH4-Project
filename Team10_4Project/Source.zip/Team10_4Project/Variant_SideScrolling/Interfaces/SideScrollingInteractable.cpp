// Copyright Epic Games, Inc. All Rights Reserved.


#include "SideScrollingInteractable.h"

// Add default functionality here for any IInteractable functions that are not pure virtual.
