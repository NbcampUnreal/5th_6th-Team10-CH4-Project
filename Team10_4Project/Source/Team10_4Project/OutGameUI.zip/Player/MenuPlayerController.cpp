﻿#include "OutGameUI/Player/MenuPlayerController.h"
#include "Blueprint/UserWidget.h"
#include "OutGameUI/UI/MainMenuWidget.h"
#include "OutGameUI/UI/ServerBrowserWidget.h"
#include "OutGameUI/UI/LobbyWidget.h"
#include "MenuPlayerState.h"
#include "OutGameUI/GameMode/MenuLobbyGameMode.h"
#include "OutGameUI/UI/HostGuestWidget.h"
#include "InGameUI/JKH/EOSSubsystem.h"

void AMenuPlayerController::BeginPlay()
{
    Super::BeginPlay();
    if (IsLocalController())
    {
        bShowMouseCursor = true;
        SetInputMode(FInputModeUIOnly());

        // [추가] 게임 시작 시 EOS 로그인 시도 (JKHTestPlayerController 로직 참조)
        if (UGameInstance* GI = GetGameInstance())
        {
            if (UEOSSubsystem* EOS = GI->GetSubsystem<UEOSSubsystem>())
            {
                // 현재 설정된 개발자 인증 도구 주소와 자격 증명 사용
                EOS->LoginToEOS("localhost:8081", "test", "Developer");
            }
        }

        ShowMainMenu();
    }
}
void AMenuPlayerController::ClearCurrentWidget()
{
    if (CurrentWidget)
    {
        CurrentWidget->RemoveFromParent();
        CurrentWidget = nullptr;
    }
}

void AMenuPlayerController::ShowMainMenu()
{
    ClearCurrentWidget();
    if (MainMenuWidgetClass)
    {
        CurrentWidget = CreateWidget<UMainMenuWidget>(this, MainMenuWidgetClass);
        if (CurrentWidget) CurrentWidget->AddToViewport();
    }
}

void AMenuPlayerController::ShowServerBrowser()
{
    ClearCurrentWidget();
    if (ServerBrowserWidgetClass)
    {
        CurrentWidget = CreateWidget<UServerBrowserWidget>(this, ServerBrowserWidgetClass);
        if (CurrentWidget) CurrentWidget->AddToViewport();
    }
}

void AMenuPlayerController::ShowLobby()
{
    ClearCurrentWidget();
    if (!LobbyWidgetClass) return;

    ULobbyWidget* LobbyWidget = CreateWidget<ULobbyWidget>(this, LobbyWidgetClass);
    if (LobbyWidget)
    {
        CurrentWidget = LobbyWidget;
        CurrentWidget->AddToViewport();

        // 마우스 커서 활성화
        bShowMouseCursor = true;

        // 위젯의 포커스 가능 여부를 코드에서도 명시적으로 확인/설정 가능
        LobbyWidget->SetIsFocusable(true);

        // 입력 모드 설정
        FInputModeUIOnly InputMode;
        InputMode.SetWidgetToFocus(LobbyWidget->GetCachedWidget()); // TakeWidget() 대신 GetCachedWidget() 시도
        InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);

        SetInputMode(InputMode);
    }
}

void AMenuPlayerController::JoinLobbyLevel()
{
    // [보완] 호스트(서버)가 세션 생성 성공 후 호출하게 됩니다.
    if (HasAuthority())
    {
        // 1. 대소문자 및 ?listen 옵션 추가 (게스트 접속 허용을 위해 필수)
        // 경로는 실제 폴더명 Team10의 대소문자를 확인하세요.
        FString LobbyPath = TEXT("/Game/Team10/OutGameUI/L_Lobby?listen");

        UE_LOG(LogTemp, Warning, TEXT("Host attempting ServerTravel to Lobby: %s"), *LobbyPath);

        if (UWorld* World = GetWorld())
        {
            // 세션이 유효하게 생성된 상태에서 이 명령이 실행되면 멀티플레이어 서버가 열립니다.
            World->ServerTravel(LobbyPath);
        }
    }
}
void AMenuPlayerController::RequestToggleReady() { Server_ToggleReady(); }

void AMenuPlayerController::Server_ToggleReady_Implementation()
{
    if (AMenuPlayerState* PS = GetPlayerState<AMenuPlayerState>())
    {
        PS->SetReady(!PS->IsReady());
        if (AMenuLobbyGameMode* LobbyGM = Cast<AMenuLobbyGameMode>(GetWorld()->GetAuthGameMode()))
        {
            // 전원 준비 시 로직은 필요에 따라 추가
        }
    }
}

void AMenuPlayerController::RequestStartGame() { Server_StartGame(); }
bool AMenuPlayerController::Server_StartGame_Validate() { return true; }
void AMenuPlayerController::Server_StartGame_Implementation()
{
    if (AMenuLobbyGameMode* LobbyGM = Cast<AMenuLobbyGameMode>(GetWorld()->GetAuthGameMode()))
    {
        LobbyGM->StartGame();
    }
}

void AMenuPlayerController::ShowHostGuestMenu()
{
    ClearCurrentWidget();

    if (HostGuestWidgetClass)
    {
        UHostGuestWidget* HostGuestWidget = CreateWidget<UHostGuestWidget>(this, HostGuestWidgetClass);
        if (HostGuestWidget)
        {
            CurrentWidget = HostGuestWidget;
            CurrentWidget->AddToViewport();

            FInputModeUIOnly InputMode;
            InputMode.SetWidgetToFocus(CurrentWidget->TakeWidget());
            SetInputMode(InputMode);
            bShowMouseCursor = true;
        }
    }
}

//void AMenuPlayerController::ClientJoinServer(const FString& Address)
//{
//    if (IsLocalController())
//    {
//        UE_LOG(LogTemp, Log, TEXT("Guest traveling to Address: %s"), *Address);
//        // 클라이언트를 해당 IP/주소로 보냅니다.
//        ClientTravel(Address, ETravelType::TRAVEL_Absolute);
//    }
//}

void AMenuPlayerController::HostCreateAndTravel()
{
    if (UEOSSubsystem* EOS = GetGameInstance()->GetSubsystem<UEOSSubsystem>())
    {
        // 1. 세션 생성을 먼저 요청 (JKH 소스 활용)
        EOS->CreateLobbySession(4, false);

        // 2. [중요] 세션 생성이 완료될 때까지 기다렸다가 이동해야 합니다.
        // 현재는 수동 호출 방식이므로, 버튼 클릭 시 이동 함수를 예약하거나 
        // 생성 성공 로그 확인 후 JoinLobbyLevel()이 호출되게 합니다.
        JoinLobbyLevel();
    }
}