﻿#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "LobbyWidget.generated.h"

UCLASS()
class TEAM10_4PROJECT_API ULobbyWidget : public UUserWidget
{
    GENERATED_BODY()

public:
    void UpdatePlayerList();

protected:
    virtual void NativeOnInitialized() override;
    virtual void NativeConstruct() override; // 권한 체크를 위해 추가

    UPROPERTY(meta = (BindWidget))
    class UButton* LeaveButton;

    UPROPERTY(meta = (BindWidget))
    class UPlayerListWidget* PlayerListWidget;

    UPROPERTY(meta = (BindWidget))
    class UButton* ReadyButton;

    UPROPERTY(meta = (BindWidget))
    class UButton* StartButton;

    UFUNCTION()
    void OnClick_Leave();
    UFUNCTION()
    void OnReadyButtonClicked();
    UFUNCTION()
    void OnStartButtonClicked();
};